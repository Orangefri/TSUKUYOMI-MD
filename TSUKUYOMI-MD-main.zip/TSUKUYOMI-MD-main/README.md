# 𝑻𝑺𝑼𝑲𝑼𝒀𝑶𝑴𝑰 𝑴𝑫    #Itachi(V6)
<p align="center">
<a href="https://github.com/Tristan7122/TSUKUYOMI-MUILT-DEVICE"><img title="Author" src="https://files.catbox.moe/qf4ipv.jpg?style=for-the-badge&logo=github"></a>

----------

<a><img src='https://i.imgur.com/LyHic3i.gif'/></a>

-------

 <p align="center">
  <a href="#"><img src="http://readme-typing-svg.herokuapp.com?color=00008B&center=true&vCenter=true&multiline=false&lines=`INFINITE+-+TSUKUYOMI+-+MD+WHATSAPP+BOT`" alt="">

------------


<br>

`❀❀❀❀❀❀❀❀❀❀❀❀❀❀❀❀❀❀❀❀❀❀`

<br>

  <p align="center">
<a href="https://github.com/Tristan7122/TSUKUYOMI-MUILT-DEVICE/followers"><img title="Followers" src="https://img.shields.io/github/followers/TSUKUYOMI?color=blue&style=flat-square"></a>
<a href="https://github.com/Tristan7122/TSUKUYOMI-MUILT-DEVICE/stargazers/"><img title="Stars" src="https://img.shields.io/github/stars/GlobalTechInfo/SUHAIL-XMD?color=blue&style=flat-square"></a>
<a href="https://github.com/Tristan7122/TSUKUYOMI-MUILT-DEVICE/network/members"><img title="Forks" src="https://img.shields.io/github/forks/https://github.com/Tristan7122/TSUKUYOMI-MUILT-DEVICE?color=blue&style=flat-square"></a>
<a href="https://github.com/Tristan7122/TSUKUYOMI-MUILT-DEVICE/"><img title="Size" src="https://img.shields.io/github/repo-size/Tristan7122/TSUKUYOMI-MUILT-DEVICE?style=flat-square&color=green"></a>
<a href="https://github.com/Tristan7122/TSUKUYOMI-MUILT-DEVICE/graphs/commit-activity"><img height="20" src="https://img.shields.io/badge/Maintained%3F-yes-green.svg"></a>&nbsp;&nbsp;
</p>
<p align='center'>
</p>
   
<p align="center">

  <a aria-label="Join our chats" href="https://t.me/GlobalBotInc" target="_blank">
    <img alt="telegram" src="https://img.shields.io/badge/Join Group-25D366?style=for-the-badge&logo=telegram&logoColor=white" />
  </a>
 

---


 <p align="center"><img src="https://profile-counter.glitch.me/{TSUKUYOMI-XMD}/count.svg" alt="MULTI DEVICE BOT:: Visitor's Count" old_src="https://profile-counter.glitch.me/{MULTI DEVICE BOT}/count.svg" /></p>


  <p align="center"> Meet 𝑻𝑺𝑼𝑲𝑼𝒀𝑶𝑴𝑰 𝑴𝑫, Your All-in-One WhatsApp Excitement Buddy! Enjoy a thrilling messaging experience like never before. TSUKUYOMI_x whatsapp bot brings a world of excitement and joy to your chats. Express yourself with unique flair and add a touch of excitement to every conversation. ✨🤖 </p
  
  <a href="https://github.com/Tristan7122/TSUKUYOMI-MUILT-DEVICE/fork"><img title="𝑻𝑺𝑼𝑲𝑼𝒀𝑶𝑴𝑰 𝑴𝑫" src="https://img.shields.io/badge/FORK-𝑻𝑺𝑼𝑲𝑼𝒀𝑶𝑴𝑰 𝑴𝑫-h?color=blue&style=for-the-badge&logo=stackshare"></a>


 

 
## Deployment Methods
---

1. ***Get [`SESSION ID`](https://tsukuyomi-md-vtsf.onrender.com/)  by Pair Code Or scanning QR code. `Whatapp>Three dots>Linked Devices`***

2.  ***Get a Mongodb uri from [`Mongodb`] | [`Tutorial`](https://youtu.be).***
3.  ***`Star ⭐` repository & Click [`FORK`](https://github.com/Tristan7122/TSUKUYOMI-MUILT-DEVICE)***
   
4.  #### DEPLOY IN HEROKU 

[![Deploy](https://www.herokucdn.com/deploy/button.svg)](https://heroku.com/deploy?template=new)

--------
5.  #### DEPLOY IN REPLIT

   <a href='https://repl.it/github/GlobalTechInfo/𝑻𝑺𝑼𝑲𝑼𝒀𝑶𝑴𝑰 𝑴𝑫' target="_blank"><img alt='DEPLOY' src='https://img.shields.io/badge/-REPLIT-orange?style=for-the-badge&logo=replit&logoColor=white'/></a>

--------
6.  #### DEPLOY IN KOYEB

<a href='https://app.koyeb.com/auth/signin' target="_blank"><img alt='DEPLOY' src='https://img.shields.io/badge/-KOYEB-blue?style=for-the-badge&logo=koyeb&logoColor=white'/></a>

--------
7.  #### DEPLOY IN GLITCH

<a href='https://glitch.com/signup' target="_blank"><img alt='DEPLOY' src='https://img.shields.io/badge/GLITCH-h?color=pink&style=for-the-badge&logo=glitch'/></a></p>

--------

8.  #### DEPLOY TO CODESPACE

<a href='https://github.com/codespaces/new' target="_blank"><img alt='DEPLOY' src='https://img.shields.io/badge/CODESPACE-h?color=navy&style=for-the-badge&logo=visualstudiocode'/></a></p>

--------

9. #### DEPLOY TO RENDER

<a href='https://dashboard.render.com' target="_blank"><img alt='DEPLOY' src='https://img.shields.io/badge/RENDER-h?color=maroon&style=for-the-badge&logo=render'/></a></p>

--------
10. #### DEPLOY TO RAILWAY

<a href='https://railway.app/new' target="_blank"><img alt='DEPLOY' src='https://img.shields.io/badge/RAILWAY-h?color=black&style=for-the-badge&logo=railway'/></a></p>

--------


---

11. ## Deploy on VPS or PC
- You need to Install git,ffmpeg,curl,nodejs,yarn with pm2 
   1. Install git ffmpeg curl 
      ``` 
       sudo apt -y update &&  sudo apt -y upgrade 
       sudo apt -y install git ffmpeg curl imagemagick
      ``` 
   2. Install nodejs  
      ```   
      sudo apt -y remove nodejs
      curl -fsSl https://deb.nodesource.com/setup_lts.x | sudo bash - && sudo apt -y install nodejs
      ```
  
   3. Install yarn
      ```
      curl -sS https://dl.yarnpkg.com/debian/pubkey.gpg | sudo apt-key add - 
      echo "deb https://dl.yarnpkg.com/debian/ stable main" | sudo tee /etc/apt/sources.list.d/yarn.list
      sudo apt -y update && sudo apt -y install yarn
      ```  
  
   4. Install pm2
      ```
      sudo yarn global add pm2
      ```
  
   5. Clone Repo and install required packages
      ```
      git clone https://github.com/Tristan7122/TSUKUYOMI-MUILT-DEVICE
      cd TSUKUYOMI-MD 
      yarn install --network-concurrency 1 && npm install
      ```

   6. Create an env file for ENV. 
      ```
      touch config.env
      nano config.env
      ```
      copy paste lines below.

      ```
      OWNER_NUMBER="27710200228"
      SESSION_ID = "SESSION_85_23_59_01_kjgfgfclhj"
      THUMB_IMAGE = "https://www.imghippo.com/i/DmYX9341LA.jpg"
      OWNER_NAME = "ORANGE"
      PREFIX = .
      WARN_COUNT = 3
      DISABLE_PM = "false"
      THEME= "BLOOD RED"
      MODE = "public"
      ANTILINK_VALUES = "https://,chat.whatsapp.com"
      
      ```
      ctrl + s and ctrl + x, To save and exit

   7. start and stop bot
 
      To start bot ``` npm start ```,
      To stop bot ``` npm stop ```

### NO TUTORIAL YET

-------

12.   ## TERMUX/UBUNTU
_First Of All Fork The Repo Then You'll Be Able To Do All The Remaining Steps.Add environment variables in config.env and config.js then run
following commands_
```
apt update && apt -y upgrade
```
```
apt install proot-distro
```
```
proot-distro install ubuntu
```
```
proot-distro login ubuntu
```
```
apt-get update && apt-get -y full-upgrade
```
```
apt install -y sudo
```
```
sudo apt -y install git ffmpeg curl imagemagick webp
```
```
sudo apt -y remove nodejs
curl -fsSl https://deb.nodesource.com/setup_lts.x | sudo bash - && sudo apt -y install nodejs
```
```
curl -sS https://dl.yarnpkg.com/debian/pubkey.gpg | sudo apt-key add - 
echo "deb https://dl.yarnpkg.com/debian/ stable main" | sudo tee /etc/apt/sources.list.d/yarn.list
sudo apt -y update && sudo apt -y install yarn
```
```
sudo yarn global add pm2
```
_Before Cloning It,Make Sure Get Session ID Via Pairing Or Scanning.Add Session ID And Owner Number In config.env And config.js.This Process Can Be Done In Fork Only.After That Clone The Fork And Execute Remaining Commands._

```
git clone https://github.com/<your_username>/TSUKUYOMI-MD
```
```
cd TSUKUYOMI-MD
```
```
npm install
```
```
npm start
```
  
 ---
 
<h2 align="center">  NOTICE </h2>
---
- *𝑻𝑺𝑼𝑲𝑼𝒀𝑶𝑴𝑰 𝑴𝑫 is not made by `WhatsApp Inc.` Sometimes or misusing the bot might `ban` your `WhatsApp account!`*
- *In that case, I'm not responsible for banning your account.*
- *Use 𝑻𝑺𝑼𝑲𝑼𝒀𝑶𝑴𝑰 𝑴𝑫 at your own risk by keeping this warning in mind.*
 

- Star ⭐ repo if you like this bot.
- 
[![JOIN WHATSAPP SUPPORT](https://raw.githubusercontent.com/Neeraj-x0/Neeraj-x0/main/photos/suddidina-join-whatsapp.png)](https://chat.whatsapp.com/CicqD04sNCJ37j13LiI51p)
--------


### CONTRIBUTORS
<a href="https://files.catbox.moe/iieoes.jpg"><img src="https://github.com/LordeVraps".png" width="200" height="200" alt="LordeVraps"/></a>


<a href="https://files.catbox.moe/iieoes.jpg
"><img src="https://github.com/Ghost7798.png" width="200" height="200" alt="Ghost7798"/></a>



# TSUKUYOMI-MULTI-DEVICE



